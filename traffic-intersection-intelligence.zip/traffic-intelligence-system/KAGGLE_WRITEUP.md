# Traffic Intersection Intelligence: An Adaptive Signal-Control Agent for Indian Smart Cities

**Capstone submission — Google × Kaggle 5-Day AI Agents: Intensive Vibe Coding Course**

🔗 **Code**: `https://github.com/<your-username>/traffic-intersection-intelligence`
🎥 **Video**: *(link to your YouTube submission here)*

---

## The problem

Most signalized intersections in Indian cities run on **fixed-cycle timers** — every approach gets the same number of seconds of green light, every cycle, regardless of how much traffic is actually waiting. A busy arterial road and a quiet side street are treated identically. The result is traffic that everyone in an Indian city recognizes: long backups on the main road while a side street's green light burns empty.

I wanted to build something that demonstrates, with hard numbers rather than a claim, that a simple **autonomous decision-making agent** watching real-time queue state can do meaningfully better than a fixed timer — without needing expensive sensor infrastructure, a black-box ML model, or real camera feeds to prove the concept first.

## What I built

A **Traffic Intersection Intelligence System**: a tick-based simulation of a 4-way signalized intersection, populated with an Indian-traffic-realistic mix of vehicles (two-wheelers, cars, auto-rickshaws, buses, trucks, cycles), and driven by two competing signal-control strategies:

1. **Fixed-timing controller** — the baseline. Each phase gets a fixed minimum green duration, then yields, round-robin.
2. **Adaptive controller (the agent)** — every simulation tick, it observes the live queue length on all four approaches and autonomously decides whether to extend the current green phase or end it, based on how much busier the active side is relative to the waiting side. It has a minimum green (no flicker, no total starvation) and a maximum green (no monopolizing the signal forever) — the agentic part is the moment-to-moment extend/yield decision in between.

This is the agent: a continuously-running, tool-free, rule-based decision loop that perceives state (queue lengths) and acts (green/yellow/red transitions) to optimize an outcome (wait time) — built incrementally through a vibe-coding loop of "run it → look at the actual numbers → find the controller isn't behaving as claimed → fix the decision logic → re-run" until the behavior was real and reproducible, not just plausible-looking.

I also built:
- **7 Indian city traffic profiles** (Mumbai, Delhi, Bangalore, Chennai, Pune, and two generic city tiers) — each with its own vehicle mix, peak-hour windows, and arrival-rate calibration.
- A **congestion analytics layer** that classifies live traffic into Free-Flow / Light / Moderate / Heavy / Severe, and computes throughput, wait time, and signal-violation rate.
- A **CLI** (`simulate`, `compare`, `cities`) so the comparison is one command away and fully reproducible with a seed.
- **42 passing unit tests** and a GitHub Actions CI workflow.

## How I built it (the vibe-coding process)

I built this conversationally, in cycles of "describe the behavior I want → get code → actually run it and read the numbers → catch where reality didn't match the description → fix it." Two moments mattered most:

**The benchmark was lying to me.** Early on, the adaptive controller showed almost zero improvement over fixed timing. Rather than accept "it works" on faith, I ran the simulation tick-by-tick and printed the actual queue states. The controller's `min_green_s=15` floor meant that by the time it was *allowed* to make a decision, the busy direction had already piled up — the agent was perceiving state too late to act on it. I lowered the absolute floor and added a starvation check that lets the agent cut a phase short *before* the normal minimum if the other side is badly backed up. That's the difference between an agent that has a sensor and an agent that actually uses it in time.

**The numbers were silently wrong.** I found that `Vehicle.speed_kmh` was being assigned from Python's global, unseeded `random` module instead of the simulator's seeded RNG — meaning "reproducible" runs with the same seed weren't actually reproducible. A test (`test_deterministic_with_same_seed`) caught it. I moved speed assignment into the simulator's own seeded RNG and re-validated every benchmark number in this writeup after the fix.

## Results

Running the fixed and adaptive controllers on **identical traffic** (same seed, same arrival pattern — an arterial road scenario where North/South gets 2x the traffic of East/West), over a 50-minute simulated window:

| Metric | Fixed-Timing | Adaptive Agent | Change |
|---|---|---|---|
| Busy approach (N/S) completed wait time | 14.4s | 13.0s | **−9.7%** |
| Side-street (E/W) completed wait time | 17.9s | 21.9s | +22.3% |
| Signal violations | 32 | 31 | −3% |

This holds consistently across multiple random seeds (verified at seeds 1, 2, 3, 99 — N/S wait reduction ranged from −9.7% to −13.7%). It's an honest trade-off, not a free win: the agent reallocates green time toward whichever side actually needs it, which **is** the cost of demand-responsive control — exactly what real-world adaptive signals do.

## Why this matters for Indian cities

Indian traffic isn't short on data collection proposals — it's short on **simple, explainable, deployable decision logic** that traffic engineers can audit and trust. This agent's entire decision rule fits in about 15 lines and only needs a queue-length estimate per approach (something a basic camera + counting model, or even induction loops, can provide). No GPU inference, no black box. That's a deliberate design choice: the most useful agent for this problem is the one a city's traffic department can actually explain to a regulator.

## Limitations & honesty about scope

- All city traffic figures (vehicle mix, arrival rates, peak hours) are **illustrative approximations**, not measured municipal data — calibrated to feel realistic, not to match a specific city's actual counts.
- This is a 2-phase, 4-way intersection model; real intersections often have more complex turn-lane phasing.
- The "agent" here is a rule-based perceive-act loop, not an LLM-based agent — I chose this because the course's emphasis on quality, security, and explainability (Day 4) pushed me toward a decision system I could fully verify rather than one I'd have to trust.

## What I'd extend next

- Replace the simulated vehicle spawner with a real computer-vision pipeline (e.g. YOLO + a tracker) feeding the same `Lane`/`Vehicle` data structures — the analytics and signal-control layers don't need to change.
- Add a reinforcement-learning controller behind the same `SignalController` interface and benchmark it against this rule-based agent using the same `compare_to_baseline` tooling.
- Extend from a single intersection to a corridor of coordinated intersections (green-wave timing).

## Try it yourself

```bash
git clone https://github.com/<your-username>/traffic-intersection-intelligence.git
cd traffic-intersection-intelligence
pip install -r requirements.txt
python -m traffic_intel.cli compare --city mumbai --minutes 50 --asymmetric --seed 1
```

Full code, tests, and a demo notebook are in the linked repository.
